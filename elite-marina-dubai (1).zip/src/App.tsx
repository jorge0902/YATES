import React from "react";
import { HeroSection } from "./components/HeroSection";
import { StatsSection } from "./components/StatsSection";
import { CurationsSection } from "./components/CurationsSection";
import { CursorWake } from "./components/CursorWake";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-[var(--color-light)] text-[var(--color-dark)] selection:bg-[var(--color-accent)] selection:text-white font-sans">
      <CursorWake />
      <Header />
      
      <main className="relative z-10">
        <HeroSection />
        <StatsSection />
        <CurationsSection />
      </main>

      <Footer />
    </div>
  );
}
