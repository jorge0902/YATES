import React from "react";
import { Film, Plane, Flower2 } from "lucide-react";

const features = [
  {
    icon: Film,
    title: "ONBOARD CINEMA",
    desc: "A private 12-seat theater with state-of-the-art Dolby Atmos surround sound.",
  },
  {
    icon: Plane,
    title: "TOUCH-AND-GO HELIPAD",
    desc: "Seamless arrival and departure for high-profile guests directly on the bow.",
  },
  {
    icon: Flower2,
    title: "PRIVATE SANCTUARY SPA",
    desc: "Full-service wellness center including a sauna, hammam, and massage suite.",
  },
];

export function CurationsSection() {
  return (
    <section className="bg-[var(--color-light)] py-24">
      <div className="container mx-auto px-8 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Image Grid */}
          <div className="grid grid-cols-2 gap-4">
            <img
              src="https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&q=80&w=800"
              alt="Deck"
              className="col-span-2 w-full h-64 object-cover rounded-2xl grayscale"
            />
            <img
              src="https://images.unsplash.com/photo-1605281317010-fe5ffe798166?auto=format&fit=crop&q=80&w=400"
              alt="Exterior"
              className="w-full h-48 object-cover rounded-2xl grayscale"
            />
            <img
              src="https://images.unsplash.com/photo-1588668214407-6ea9a6d8c272?auto=format&fit=crop&q=80&w=400"
              alt="Interior"
              className="w-full h-48 object-cover rounded-2xl grayscale"
            />
          </div>

          {/* Content */}
          <div>
            <h2 className="text-5xl font-black italic text-[var(--color-dark)] uppercase tracking-tighter mb-6">
              BESPOKE <span className="text-[var(--color-accent)]">CURATIONS</span>
            </h2>
            <p className="text-gray-500 mb-12 leading-relaxed">
              Designed by Cristiano Gatto Design Studio in Italy, every square inch of the Majesty 175 is crafted to evoke a sense of boundless space and tranquility.
            </p>

            <div className="space-y-8">
              {features.map((feat, idx) => (
                <div key={idx} className="flex gap-6">
                  <div className="flex-shrink-0 w-12 h-12 bg-[var(--color-accent)]/10 rounded-lg flex items-center justify-center text-[var(--color-accent)]">
                    <feat.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-[var(--color-dark)] uppercase tracking-wide mb-1">
                      {feat.title}
                    </h3>
                    <p className="text-sm text-gray-500 leading-relaxed">
                      {feat.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
