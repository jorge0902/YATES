import React from "react";
import { Ship } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-[#111111] text-white pt-24 pb-12">
      <div className="container mx-auto px-8 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16 mb-24">
          <div>
            <div className="flex items-center gap-3 text-white mb-6">
              <Ship className="h-6 w-6 text-[var(--color-accent)]" />
              <span className="font-black italic text-xl tracking-widest uppercase">MAJESTY 175</span>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
              The pinnacle of Gulf Craft's manufacturing excellence. A vessel that doesn't just sail the seas, but commands them with unparalleled grace and technical superiority.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold uppercase tracking-widest mb-6 text-sm">Contact</h4>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-[var(--color-accent)] transition-colors">Charter Desk</a></li>
              <li><a href="#" className="hover:text-[var(--color-accent)] transition-colors">Ownership Inquiry</a></li>
              <li><a href="#" className="hover:text-[var(--color-accent)] transition-colors">Press Office</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold uppercase tracking-widest mb-6 text-sm">Connect</h4>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-[var(--color-accent)] transition-colors">Instagram</a></li>
              <li><a href="#" className="hover:text-[var(--color-accent)] transition-colors">LinkedIn</a></li>
              <li><a href="#" className="hover:text-[var(--color-accent)] transition-colors">YouTube</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between pt-8 border-t border-white/10 text-xs text-gray-500 font-bold uppercase tracking-widest">
          <p>© {new Date().getFullYear()} MAJESTY YACHTS INTERNATIONAL. ALL RIGHTS RESERVED.</p>
          <div className="flex gap-8 mt-4 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
