import React, { useState } from "react";
import { Ship, Share2, Heart } from "lucide-react";
import { motion, useScroll, useMotionValueEvent } from "framer-motion";

export function Header() {
  const { scrollY } = useScroll();
  const [hidden, setHidden] = useState(false);

  useMotionValueEvent(scrollY, "change", (latest) => {
    const previous = scrollY.getPrevious() ?? 0;
    if (latest > previous && latest > 150) {
      setHidden(true);
    } else {
      setHidden(false);
    }
  });

  return (
    <motion.header
      variants={{
        visible: { y: 0 },
        hidden: { y: "-100%" },
      }}
      animate={hidden ? "hidden" : "visible"}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className="fixed top-0 left-0 w-full z-50 bg-black/20 backdrop-blur-md border-b border-white/10"
    >
      <div className="container mx-auto px-8 h-20 flex items-center justify-between">
        <div className="flex items-center gap-3 text-white">
          <Ship className="h-6 w-6 text-[var(--color-accent)]" />
          <span className="font-black italic text-xl tracking-widest uppercase">MAJESTY 175</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-8 text-xs font-bold tracking-widest text-white uppercase">
          <a href="#" className="hover:text-[var(--color-accent)] transition-colors">The Gallery</a>
          <a href="#" className="hover:text-[var(--color-accent)] transition-colors">Specifications</a>
          <a href="#" className="hover:text-[var(--color-accent)] transition-colors">Amenities</a>
          <a href="#" className="hover:text-[var(--color-accent)] transition-colors">Enquire</a>
        </nav>

        <div className="flex items-center gap-4">
          <button className="w-10 h-10 rounded-full bg-black/40 flex items-center justify-center text-white hover:bg-[var(--color-accent)] transition-colors">
            <Share2 className="h-4 w-4" />
          </button>
          <button className="w-10 h-10 rounded-full bg-black/40 flex items-center justify-center text-white hover:bg-[var(--color-accent)] transition-colors">
            <Heart className="h-4 w-4" />
          </button>
        </div>
      </div>
    </motion.header>
  );
}

