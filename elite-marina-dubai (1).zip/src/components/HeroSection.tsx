import React from "react";
import { motion } from "framer-motion";
import { MapPin, ArrowRight } from "lucide-react";

export function HeroSection() {
  return (
    <section className="relative h-screen w-full">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1567899378494-47b22a2ae96a?auto=format&fit=crop&q=80&w=2000"
          alt="Yacht"
          className="w-full h-full object-cover grayscale brightness-50"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex h-full items-center px-8 md:px-16 lg:px-24">
        <div className="max-w-3xl mt-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 text-white mb-4"
          >
            <MapPin className="h-5 w-5 text-[var(--color-accent)]" />
            <span className="text-sm font-bold tracking-widest uppercase">Dubai Marina, UAE</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-6xl md:text-8xl lg:text-9xl font-black italic text-white uppercase leading-none tracking-tighter mb-6"
          >
            THE MAJESTY<span className="text-[var(--color-accent)]">175</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-lg md:text-xl text-white/80 max-w-xl mb-10 leading-relaxed"
          >
            A masterpiece of naval architecture, the Majesty 175 is the world's largest composite production mega-yacht, redefining the limits of luxury engineering.
          </motion.p>

          <motion.button
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-[var(--color-accent)] hover:bg-[#e04d1c] text-white px-8 py-4 rounded-full font-bold uppercase tracking-wider flex items-center gap-3 transition-colors"
          >
            Reserve This Vessel <ArrowRight className="h-5 w-5" />
          </motion.button>
        </div>
      </div>
    </section>
  );
}
