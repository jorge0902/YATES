import React from "react";
import { cn } from "../lib/utils";

interface InteractiveHoverButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  text: string;
  className?: string;
}

export const InteractiveHoverButton = React.forwardRef<HTMLButtonElement, InteractiveHoverButtonProps>(
  ({ text, className, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "group relative inline-flex items-center justify-center overflow-hidden rounded-full border border-[var(--color-gold)] bg-transparent px-8 py-4 font-sans text-sm font-medium tracking-widest text-[var(--color-gold)] uppercase transition-all duration-300 hover:bg-[var(--color-gold)] hover:text-black",
          className
        )}
        {...props}
      >
        <span className="relative z-10">{text}</span>
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
      </button>
    );
  }
);

InteractiveHoverButton.displayName = "InteractiveHoverButton";
