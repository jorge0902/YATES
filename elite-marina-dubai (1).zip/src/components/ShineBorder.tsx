import React from "react";
import { cn } from "../lib/utils";

interface ShineBorderProps {
  children: React.ReactNode;
  className?: string;
  color?: string | string[];
}

export function ShineBorder({
  children,
  className,
  color = ["#D4AF37", "#FFFFFF", "#D4AF37"],
}: ShineBorderProps) {
  return (
    <div
      className={cn(
        "relative rounded-2xl p-[1px] overflow-hidden group",
        className
      )}
    >
      <div
        className="absolute inset-0 z-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: `linear-gradient(90deg, ${Array.isArray(color) ? color.join(", ") : color})`,
          backgroundSize: "200% 200%",
          animation: "gradient-shift 3s ease infinite",
        }}
      />
      <div className="relative z-10 h-full w-full rounded-2xl bg-black">
        {children}
      </div>
    </div>
  );
}
