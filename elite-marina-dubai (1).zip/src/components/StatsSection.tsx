import React from "react";

const stats = [
  { id: "01", label: "TOTAL LENGTH", value: "54.4 Meters" },
  { id: "02", label: "GUEST CAPACITY", value: "14 Guests" },
  { id: "03", label: "STATEROOMS", value: "7 Ultra-Suites" },
];

export function StatsSection() {
  return (
    <section className="bg-[var(--color-light)] py-24 border-b border-gray-200">
      <div className="container mx-auto px-8 md:px-16 lg:px-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 divide-y md:divide-y-0 md:divide-x divide-gray-300">
          {stats.map((stat, index) => (
            <div key={stat.id} className={`pt-8 md:pt-0 ${index !== 0 ? 'md:pl-12' : ''}`}>
              <div className="text-6xl font-black text-[var(--color-accent)] opacity-20 mb-2">
                {stat.id}
              </div>
              <div className="text-xs font-bold text-gray-400 tracking-widest uppercase mb-1">
                {stat.label}
              </div>
              <div className="text-3xl font-black italic text-[var(--color-dark)]">
                {stat.value}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
